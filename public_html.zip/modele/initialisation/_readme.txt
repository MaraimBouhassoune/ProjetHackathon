Le fichier d'inialisation est chargé au départ  de tous les controleurs

Il démmarre une session

Il charge les fonctions de debug

Il charge les classes 

Il se connecte à la BD

Il définit des variables globales : 
      le $copyright
<?php
header('Location: ' . './ctrls/ctrl_accueil.php');

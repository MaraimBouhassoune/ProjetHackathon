<meta charset="UTF-8">
<title>Hackathon</title>
<script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
<link rel="stylesheet" href="../public/css/style.css">
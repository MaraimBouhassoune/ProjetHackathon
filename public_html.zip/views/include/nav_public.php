<ul>
   <li><a href="../ctrls/ctrl_accueil.php">Accueil public</a></li>
   <li><a href="../ctrls/ctrl_api.php">API</a></li>
</ul>
<div>
   <ul>
      <li><a href="../ctrls/ctrl_connexion.php">Login</a></li>
   </ul>
</div>